INTRODUCTION

Implementation of LABYRINTH: WAR ON TERROR for the open source Saito Game Engine.

As a fan of GMT Games and open source gaming, our hope is that this module helps introduce new players to the company and the game. Please see the /licence directory for legalese. The code that implements the game rules is released under the MIT license for all uses atop the Saito Game Engine. All GMT-developed materials (board design, cards, gameplay text) remain owned by GMT Games and are distributed under their license which provides for gameplay and distribution under the following conditions:

    1. The game files may only be used by open source, non-commercial game engines

    2. At least ONE player in every game should have purchased a commercial copy of the game.

If you are a player or developer who enjoys playing around with this implementation, please respect the goodwill shown by GMT Games and purchase a copy of the game. Likewise, if you make this demo available for play on a public server, please make sure that any players you support can fulfill these conditions by making it easy for them to purchase commercial copies of the game.

AMAZON:
https://www.amazon.com/GMT-Games-Labyrinth-War-Terror/dp/B005UQ3FLU
