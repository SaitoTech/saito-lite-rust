This test suite is presented as a Saito module.

To install this module:

1. copy the directory into /mods

2. edit /config/modules.config.js to include this module in both core/lite distributions

3. recompile the javascript

```
npm run nuke
```

4. restart the saito node

```
npm start
```
