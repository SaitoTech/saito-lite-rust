CREATE TABLE IF NOT EXISTS tiles (
  i       INTEGER,
  j       INTEGER,
  red     INTEGER,
  green   INTEGER,
  blue    INTEGER,
  alpha   INTEGER,
  ordinal INTEGER,
  PRIMARY KEY (i,j)
);