CREATE TABLE IF NOT EXISTS mixin_users (
  user_id TEXT DEFAULT "",
  address TEXT DEFAULT "",
  publickey TEXT DEFAULT "",
  asset_id TEXT DEFAULT "",
  created_at INTEGER DEFAULT 0,
  updated_at INTEGER DEFAULT 0
);