
} // end and export

module.exports = PathsOfGlory;


