

    //
    // Nazi Scientist
    //
    if (card == "naziscientist") {
      this.advanceSpaceRace(player);
      return 1;
    }



