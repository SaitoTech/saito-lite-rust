
    if (card == "carterdoctrine") {

      this.game.state.events.carterdoctrine = 1;
      this.updateLog(`US may ignore DEFCON restrictions on Middle East realignments for remainder of turn`);

      return 1;

    }





