
    if (card == "argo") {

      this.game.state.events.argo = 1;
      return 1;

    }





