
    if (card == "greatsociety") {

      this.game.state.events.greatsociety = 1;

      return 1;
    }

