
    if (card == "manwhosavedtheworld") {
      this.game.state.events.manwhosavedtheworld = player;
      return 1;
    }

