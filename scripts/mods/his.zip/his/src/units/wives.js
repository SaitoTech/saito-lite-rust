
    this.importWife('anne-boleyn', {
      type		:	"anne-boleyn" ,
      name		: 	"Anne Boleyn",
      personage		:	true,
      img		:	"AnneBoleyn.svg",
    });

    this.importWife('anne-cleves', {
      type		:	"anne-cleves" ,
      name		: 	"Anne Cleves",
      personage		:	true,
      img		:	"AnneCleves.svg",
    });

    this.importWife('catherine-aragon', {
      type		:	"catherine-aragon" ,
      name		: 	"Catherine Aragon",
      personage		:	true,
      img		:	"CatherinAragon.svg",
    });

    this.importWife('jane-seymour', {
      type		:	"jane-seymour" ,
      name		: 	"Jane Seymour",
      personage		:	true,
      img		:	"JaneSeymour.svg",
    });

    this.importWife('katherine-parr', {
      type		:	"katherine-parr" ,
      name		: 	"Katherine Parr",
      personage		:	true,
      img		:	"KatherineParr.svg",
    });

    this.importWife('kathryn-howard', {
      type		:	"kathryn-howard" ,
      name		: 	"Kathryn Howard",
      personage		:	true,
      img		:	"KathrynHoward.svg",
    });

