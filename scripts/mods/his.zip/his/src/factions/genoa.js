
    this.importFaction('faction7', {
      id		:	"faction7" ,
      key		:	"genoa" ,
      name		: 	"Genoa",
      nickname		: 	"Genoa",
    });
 

