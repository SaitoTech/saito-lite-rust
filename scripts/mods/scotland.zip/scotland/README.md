This is an implementation of Thirteen Days written for the open source Saito Game Engine Module. As the materials come from an officially-licensed Vassal module, it is required that:

    1. The game files may only be used by open source, non-commercial game engines

    2. At least ONE player in every game should have purchased a commercial copy of the game.

You can purchase a physical copy of the game here:

http://jollyrogergames.com/game/13-days/
